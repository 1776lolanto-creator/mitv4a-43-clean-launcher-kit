# Recovery

## Home key no longer returns to the custom launcher

```bash
./scripts/restore-accessibility.sh
```

或检查：

```bash
adb shell settings get secure enabled_accessibility_services
```

应包含：

```text
com.gathin.tvhome/.HomeKeyService
```

## Theme/wallpaper breaks the home screen

删除外部主题：

```bash
adb shell rm -f \
  /sdcard/Android/data/com.gathin.tvhome/files/config.json \
  /sdcard/Android/data/com.gathin.tvhome/files/wallpaper.jpg \
  /sdcard/Android/data/com.gathin.tvhome/files/theme_revision
```

然后重新启动 Launcher。

## Custom launcher crashes

原厂 HOME 没有被删除：

```text
com.mitv.tvhome/.MainActivityUserMode
```

这是本项目刻意保留的救援层。

## Restore user-0 removed packages

先尝试：

```bash
./scripts/restore-packages.sh
```

它使用 `cmd package install-existing`。部分 Android 6 ROM 可能不支持该命令。如果 ROM 不支持，而你必须恢复某个系统预装 App，最可靠的最终兜底仍然是恢复出厂设置。
