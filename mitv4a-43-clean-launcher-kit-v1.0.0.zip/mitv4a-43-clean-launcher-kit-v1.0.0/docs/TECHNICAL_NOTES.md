# Technical notes

## Xiaomi HOME selection

实机反查表明，ROM 处理 `MAIN + HOME` 时会优先保留系统应用或 Xiaomi 允许的第三方 HOME。因此标准 preferred-activity/chooser 方案在本机无效。

## Boot timeline from one captured boot

```text
10:04:47.613  com.mitv.tvhome/.MainActivityUserMode starts
10:04:48.318  com.gathin.tvhome HomeKeyService process starts
10:04:48.866  custom launcher starts
10:04:59.138  com.miui.systemAdSolution AdReceiver process starts
10:05:00.749  com.mitv.tvhome/.BootActivity starts
10:05:02.096  BootActivity.sendAdShowBroadcast (onCreate)
10:05:23.545  BootActivity.sendAdShowBroadcast (onDestroy)
```

这解释了为什么“开机只拉起一次自定义 Launcher”会失败。

## `com.miui.systemAdSolution`

它参与广告链路，但前台真正启动并覆盖 Launcher 的 Activity 是 `com.mitv.tvhome/.BootActivity`。

## Why BootActivity is not disabled

```bash
pm disable-user --user 0 com.mitv.tvhome/.BootActivity
```

本机返回：

```text
SecurityException: Permission Denial: attempt to change component state ... uid=2000, package uid=1000
```

通知中心 ActivityAlias 也受到同类保护。

## Wallpaper rendering

Launcher 的 `showWallpaper(File)`：

- BitmapFactory 解码
- 按屏幕尺寸 downsample
- RGB_565 降低内存
- ImageView 使用 `CENTER_CROP`
- 插入 root index 0

因此推荐直接准备 16:9 壁纸构图。
