# Tested final state

本文件记录 v1.0.0 发布时的实机终态。

## Boot

经过多次重启，最终观察到：

```text
自定义 Launcher → 短暂闪一下 → 自定义 Launcher
```

没有完整开机广告，也没有最终落回小米原厂桌面。

## Accessibility

最终保留：

```text
com.xiaomi.mitv.karaoke.service/com.loostone.puremic.voice.service.accessibility.PuremicKeyService
com.gathin.tvhome/.HomeKeyService
```

`com.xiaomi.voicecontrol/...VoiceAccessibilityService` 在卸载小爱同学前已从列表移除。

## Hidden launcher packages

```text
com.mediatek.wwtv.tvcenter
com.mitv.gallery
com.xiaomi.mitv.systemui
com.xiaomi.mitv.smartshare
```

## Wallpaper

最终主题配置：

```json
{
  "background_color": "#000000",
  "wallpaper": true,
  "sky_intensity": 0
}
```

壁纸读取需要 `READ_EXTERNAL_STORAGE` runtime grant。
