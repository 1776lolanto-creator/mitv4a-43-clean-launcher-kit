# Troubleshooting

## Theme config does nothing

先把 `config.json` 改成高对比测试：

```json
{
  "background_color": "#FF00FF",
  "wallpaper": false,
  "sky_intensity": 0
}
```

如果仍无变化：

```bash
adb logcat -d | grep -E 'TvHome\.Config|config\.json|wallpaper\.jpg'
```

本机曾出现 `EACCES (Permission denied)`，见 `patches/STORAGE_PERMISSION.md`。

## Screenshot cannot be opened

不要依赖：

```bash
adb exec-out screencap -p > screenshot.png
```

本机曾得到损坏文件。使用：

```bash
./scripts/screenshot.sh ~/Desktop
```

## HomeKeyService disappears after install/force-stop

Android 6 上安装或 `force-stop` 后无障碍服务可能被移出 enabled list：

```bash
./scripts/restore-accessibility.sh
```

## Boot ad finishes and stock home remains

检查 HomeKeyService 是否包含 45 秒保险回抢点，并确认服务在重启后真正绑定。

## `pm disable-user` returns Permission Denial

对 uid=1000 的系统组件不要继续轮番试 `pm hide`、`cmd package` 等命令。这个 ROM 明确限制 shell 修改组件状态。改用“保留系统包 + Launcher 隐藏”或 HomeKeyService 前台接管。
