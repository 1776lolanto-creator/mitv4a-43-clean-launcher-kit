# Changelog

## v1.0.0 - 2026-10-21

首个可公开发布版本，来自 MiTV4A 43 (`matrix`) / Android 6.0.1 实机调试。

- 记录 Xiaomi HOME resolver 限制
- 记录 `com.mitv.tvhome/.BootActivity` 开机广告时序
- 固化 HomeKeyService 的 Home 键和开机回抢方案
- 固化 Android 6 壁纸 `READ_EXTERNAL_STORAGE` / EACCES 修复
- 提供已验证的 user-0 删除包名单
- 保留并隐藏 SystemUI 通知中心、无线投屏
- 增加设备检查、备份、恢复、验证、截图和壁纸脚本
- 增加公开发布需要的 License、Notice、Security、Contributing 和 CI
