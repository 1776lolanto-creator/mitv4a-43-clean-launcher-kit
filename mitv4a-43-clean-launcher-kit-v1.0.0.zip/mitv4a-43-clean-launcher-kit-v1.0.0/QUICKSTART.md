# Quick start

这是给已经确认自己是 **MiTV4A 43 / matrix / Android 6.0.1 API 23** 的用户准备的最短流程。

## 1. ADB

电视开启开发者选项和 ADB 调试。电脑准备 Android Platform Tools：

```bash
export ADB="$HOME/Downloads/platform-tools/adb"
export TV_HOST="192.168.1.50"
```

连接：

```bash
"$ADB" connect "$TV_HOST:5555"
```

## 2. 识别型号

```bash
./scripts/check-device.sh
```

只有看到：

```text
Target check: PASS (matrix / API 23)
```

才继续。

## 3. 备份状态

```bash
./scripts/backup-state.sh
```

备份包含系统属性、安装包列表、无障碍服务、HOME/广告相关包信息等。

## 4. 准备 Launcher

本项目不附带上游 Launcher 源码。你的 `com.gathin.tvhome` 需要：

- 已兼容 API 23
- 应用 [`patches/HOME_TAKEOVER.md`](patches/HOME_TAKEOVER.md)
- 应用 [`patches/STORAGE_PERMISSION.md`](patches/STORAGE_PERMISSION.md)

安装后：

```bash
./scripts/restore-accessibility.sh
```

壁纸权限：

```bash
"$ADB" -s "$TV_HOST:5555" shell pm grant \
  com.gathin.tvhome android.permission.READ_EXTERNAL_STORAGE
```

## 5. 删除已验证的可选预装 App

```bash
./scripts/debloat-user-apps.sh
```

它会要求输入 `YES`。

## 6. 应用最终主题

```bash
./scripts/apply-theme.sh
```

通知中心和无线投屏仍然安装，只是不显示在 Launcher 网格。

设置壁纸：

```bash
./scripts/set-wallpaper.sh /path/to/wallpaper.jpg
```

## 7. 验证

```bash
./scripts/verify-final-state.sh
```

然后重启电视，观察：

```text
开机 → 自定义 Launcher → 最多短暂闪屏 → 自定义 Launcher
```
