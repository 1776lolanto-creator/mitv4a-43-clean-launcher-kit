# MiTV4A 43 Clean Launcher Kit

A device-specific, no-root companion kit for the **Xiaomi MiTV4A 43 China model** (`matrix`) running **Android 6.0.1 / API 23**.

It documents and automates the exact setup validated on one physical TV:

- keep the stock launcher as a recovery layer
- route the remote Home key to `com.gathin.tvhome`
- bring the custom launcher back during Xiaomi's delayed boot-ad window
- remove selected optional Xiaomi apps from user 0
- keep SystemUI and wireless casting installed but hide their launcher tiles
- enable custom wallpapers on Xiaomi's Android 6 storage stack
- capture reliable screenshots over ADB

Tested build: `8.8.20.1275`, UI `1.3.85 stable`, `armeabi-v7a`, 2 GB RAM.

This is **not a universal Xiaomi TV debloat list**. Scripts refuse the destructive step by default unless the device reports `ro.product.device=matrix` and API 23.

See [`QUICKSTART.md`](QUICKSTART.md) and the Chinese [`README.md`](README.md) for the full workflow.

## Upstream launcher

The tested setup is based on the MIT-licensed `cleanyourtv` project by Gathin23:

https://github.com/Gathin23/cleanyourtv

This repository does not vendor the upstream launcher source or font assets. See [`NOTICE.md`](NOTICE.md).

## License

Scripts and original documentation in this repository are MIT licensed.
